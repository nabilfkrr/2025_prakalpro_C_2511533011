package pekan2;

public class KelilingLingkaran {
	public static void main(String[] args) {
		final double PI = 3.14; /* Definisi Konstanta */
		double radius = 30;		/* Deklarasi Variabel */
			System.out.println("Keliling = " + 2 * PI * radius);
	}

}
