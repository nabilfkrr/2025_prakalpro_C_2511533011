package pekan1;

public class HelloWorld {

	public static void main(String[] args) {
		//program pertama
		/*komentar
		 * dua baris atau lebih
		 * pertemuan 1 praktikum alpro
		 */
		System.out.println("Hello World");
		System.out.println();
		System.out.println("program ini menghasilkan");
		System.out.println("Empat baris output");
		System.out.println("/ \\ // \\\\ /// \\\\");
		System.out.println("This"+" program prints a\n" + "quote from the Gettysburg Address.");

	}

}
